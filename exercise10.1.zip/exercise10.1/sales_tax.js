var $ = function (id) {
    return document.getElementById(id); 
}

var processEntries = function(){
    var sub_total = parseFloat($("subtotal").value);
    var Tax_Rate = parseFloat( $("tax_rate").value );
    if (sub_total<=0||sub_total >10000){
        ($("sub_msg").innerHTML = "Must be a positive number less than 10,000.");
        
    }
    if(Tax_Rate<=0||Tax_Rate >12){
        ($("taxrate_msg").innerHTML = "Must be a positive number less than 12.");
        return;
    }
    var calculate_tax = sub_total * (Tax_Rate/100);
    calculate_tax = parseFloat(calculate_tax.toFixed(2));
    var amt = sub_total +calculate_tax;
    $("total").value = amt.toFixed(2);
    $("sales_tax").value = calculate_tax;

}
var clear_click = function()
{
    $("subtotal").value = "";
    $("tax_rate").value = "";
    
    $("total").value = "";
    
    $("sales_tax").value = "";
    
}
function clearsubtotal()
{
    $("subtotal").value = "";
    
}
function cleartaxrate()
{
    $("tax_rate").value = "";
}
window.onload = function()
{
    $("calculate").onclick= processEntries;
    
    
}